package edu.javacourse.ibatis;

import edu.javacourse.ibatis.entity.City;
import edu.javacourse.ibatis.entity.Region;
import java.io.IOException;
import java.io.Reader;
import java.util.List;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class TestBatis {

    public static void main(String[] arg) {
        TestBatis tb = new TestBatis();
        try {
            tb.testBatis();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void testBatis() throws IOException {
        String resource = "edu/javacourse/ibatis/Configuration.xml";
        Reader reader = Resources.getResourceAsReader(resource);
        SqlSessionFactory sqlMapper = new SqlSessionFactoryBuilder().build(reader);

        SqlSession session = sqlMapper.openSession();
        try {
            showRegions(session);
            System.out.println();
            System.out.println();
            showCities(session);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    private void showRegions(SqlSession session) {
        List<Region> list = (List) session.selectList("ibatis.RegionMapper.selectAllRegions");
        for(Region r : list) {
            System.out.println(r.getRegionName());
            for(City c : r.getCities()) {
                System.out.println("===> " + c.getCityName());
            }
        }
    }

    private void showCities(SqlSession session) {
        List<City> list = (List) session.selectList("ibatis.RegionMapper.selectAllCities");
        for(City c : list) {
            System.out.println(c.getCityName() + " is in " + c.getRegion().getRegionName());
        }
    }
}
