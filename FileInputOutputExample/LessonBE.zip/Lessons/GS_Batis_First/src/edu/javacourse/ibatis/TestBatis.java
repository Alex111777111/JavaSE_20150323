package edu.javacourse.ibatis;

import java.io.IOException;
import java.io.Reader;
import java.util.List;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class TestBatis {

    public static void main(String[] arg) {
        TestBatis tb = new TestBatis();
        try {
            tb.testBatis();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void findAndGet(SqlSession session) {
        List<Region> list = (List) session.selectList("ibatis.RegionMapper.selectAllRegion");

        System.out.println("====> List of regions");
        int id = 0;
        for (Region r : list) {
            System.out.println("RegionID:" + r.getRegionId());
            System.out.println("RegionName:" + r.getRegionName());
            id = r.getRegionId();
        }
        System.out.println("====> One region");
        if (id != 0) {
            Region region = (Region) session.selectOne("ibatis.RegionMapper.selectRegion", id);
            System.out.println("RegionID:" + region.getRegionId());
            System.out.println("RegionName:" + region.getRegionName());
        }
        System.out.println("=======================");
    }

    private void testBatis() throws IOException {
        String resource = "edu/javacourse/ibatis/Configuration.xml";
        Reader reader = Resources.getResourceAsReader(resource);
        SqlSessionFactory sqlMapper = new SqlSessionFactoryBuilder().build(reader);

        SqlSession session = sqlMapper.openSession();
        try {
            Region region = new Region();
            region.setRegionName("Test region");
            session.insert("ibatis.RegionMapper.insertRegion", region);
            session.commit();

            findAndGet(session);

            region.setRegionName("region for test");
            session.update("ibatis.RegionMapper.updateRegion", region);
            session.commit();

            findAndGet(session);

            session.delete("ibatis.RegionMapper.deleteRegion", region.getRegionId());
            session.commit();

            findAndGet(session);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}
