package edu.javacourse.ibatis;

import java.io.IOException;
import java.io.Reader;
import java.util.List;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class TestBatis {

    public static void main(String[] arg) {
        TestBatis tb = new TestBatis();
        try {
            tb.testBatis();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void testBatis() throws IOException {
        String resource = "edu/javacourse/ibatis/Configuration.xml";
        Reader reader = Resources.getResourceAsReader(resource);
        SqlSessionFactory sqlMapper = new SqlSessionFactoryBuilder().build(reader);

        SqlSession session = sqlMapper.openSession();
        try {
            // Пример вставки с использованием предварительной установки ID
            Region region = new Region();
            region.setRegionName("Test region");
            session.insert("ibatis.RegionMapper.insertRegion", region);
            session.commit();
            
            List<Integer> list = (List) session.selectList("ibatis.RegionMapper.selectAllRegionId");
            for(Integer id : list) {
                System.out.println("ID:" + id);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}
