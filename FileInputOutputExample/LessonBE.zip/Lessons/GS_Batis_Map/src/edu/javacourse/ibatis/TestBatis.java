package edu.javacourse.ibatis;

import java.io.IOException;
import java.io.Reader;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class TestBatis {

    public static void main(String[] arg) {
        TestBatis tb = new TestBatis();
        try {
            tb.testBatis();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void testBatis() throws IOException {
        String resource = "edu/javacourse/ibatis/Configuration.xml";
        Reader reader = Resources.getResourceAsReader(resource);
        SqlSessionFactory sqlMapper = new SqlSessionFactoryBuilder().build(reader);

        SqlSession session = sqlMapper.openSession();
        try {
            List<Map> result = (List) session.selectList("ibatis.RegionMapper.selectAllRegion");
            for (Map map : result) {
                for (Object o : map.keySet()) {
                    System.out.println(o + ":" + map.get(o));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}
