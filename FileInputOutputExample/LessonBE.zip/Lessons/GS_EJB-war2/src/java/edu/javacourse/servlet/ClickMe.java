package edu.javacourse.servlet;

import edu.javacourse.ru.SimpleBeanRemote;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ASaburov
 */
@WebServlet(name = "ClickMe", urlPatterns = {"/ClickMe"})
public class ClickMe extends HttpServlet {

    // Пример механизма injection
    // Без указания имени
    @EJB
    // С указанием имени
    //@EJB(mappedName="SimpleName")
    private SimpleBeanRemote beanRemote;
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            // Представлено несколько вариантов вызова EJB через JNDI
            // Механизм injection не на всех серверах работает

            Context ic = new InitialContext();
            // Вызов через шлобальный идентификатор java:global[/app-name]/module-name/bean-name 
            // Работает для любого случая именования бина
            //SimpleBeanRemote beanRemote = (SimpleBeanRemote) ic.lookup("java:global/GS_EJB_First/GS_EJB_First-ejb/SimpleBean");

            // Этот вызов необходим, если обращение будет через RMI (по-настоящему)
            if(!SimpleBeanRemote.class.isInstance(beanRemote)) {
                beanRemote = (SimpleBeanRemote) PortableRemoteObject.narrow(beanRemote, SimpleBeanRemote.class);
            }

            // Вызов через глобальный идентификатор с указанием интерфейса
            // Работает для любого случая именования бина
            //SimpleSessionBeanRemote beanRemote = (SimpleSessionBeanRemote) ic.lookup("java:global/GS_EJB/GS_EJB-ejb/SimpleSessionBean!test.NewSessionBeanRemote");

            // Вызов через идентификатор GlassFish
            // При именовании не работает
            //SimpleSessionBeanRemote beanRemote = (SimpleSessionBeanRemote) ic.lookup("edu.javacourse.ejb.SimpleSessionBeanRemote");

            // Пример вызова по имени с атрибутом mappedBy - см. SimpleSessionBean.java
            //SimpleSessionBeanRemote beanRemote = (SimpleSessionBeanRemote) ic.lookup("SimpleBean");

            beanRemote.businessMethod();
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ClickMe</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ClickMe Remote:</h1>");
            out.println("</body>");
            out.println("</html>");
        } catch (NamingException ex) {
            ex.printStackTrace();
        } finally {
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}
