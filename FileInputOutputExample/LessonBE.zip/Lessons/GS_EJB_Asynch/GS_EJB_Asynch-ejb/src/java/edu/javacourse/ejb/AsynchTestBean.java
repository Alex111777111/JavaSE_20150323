package edu.javacourse.ejb;

import java.util.concurrent.Future;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;

@Stateless
@LocalBean
public class AsynchTestBean {

    public AsynchTestBean() {
        System.out.println("Created Asynchronous");
    }
    
    @Asynchronous
    public Future<String> sayHello() {
        try {
            Thread.sleep(5000);
            System.out.println("CHECK Simple Asynchronous");
            System.out.println("CHECK Simple Asynchronous");
            System.out.println("CHECK Simple Asynchronous");
        } catch (InterruptedException ex) {
        }
        return new AsyncResult<String>("Hello");
    }

    
}
