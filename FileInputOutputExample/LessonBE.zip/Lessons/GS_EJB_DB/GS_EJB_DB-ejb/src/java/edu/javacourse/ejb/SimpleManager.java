package edu.javacourse.ejb;

import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * 
MANDATORY - если есть, будет использовать ее, если нет - бросит 
javax.ejb.EJBTransactionRequiredException
NEVER - если нет, то и не будет. Если есть - бросит javax.ejb.EJBException
NOT_SUPPORTED - текущая транзакция "подвешивается" и не передается в другие вызовы
REQUIRED - использует текущую, если есть или автоматически начнет новую
REQUIRES_NEW - если нет, создаст новую и будет передаваться дальше, если есть - 
"подвесит" старую и создаст новую
SUPPORTS - если есть транзакция, будет использовать, если нет - ее и не будет
 * 
 */


@Stateless
@LocalBean
public class SimpleManager {

    @PersistenceContext
    private EntityManager em;

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public Region saveRegion() {
        Region c = new Region();
        c.setRegionName("RegionTest");
        System.out.println("ID before:" + c.getRegionId());
        em.persist(c);
        //em.flush();
        System.out.println("ID after:" + c.getRegionId());
        List<Region> list = em.createQuery("SELECT r FROM Region r").getResultList();
        for(Region r : list) {
            System.out.println(r);
        }
        return c;
    }
    
}
