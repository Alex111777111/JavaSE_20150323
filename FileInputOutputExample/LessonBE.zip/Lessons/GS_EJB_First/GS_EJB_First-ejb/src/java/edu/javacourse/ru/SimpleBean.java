package edu.javacourse.ru;

import javax.ejb.Stateless;

@Stateless
// Второй вариант подразумевает вызов по имени
//@Stateless(mappedName="SimpleName")
public class SimpleBean implements SimpleBeanRemote {

    @Override
    public void businessMethod() {
        System.out.println("BUSINESS METHOD");
    }
}
