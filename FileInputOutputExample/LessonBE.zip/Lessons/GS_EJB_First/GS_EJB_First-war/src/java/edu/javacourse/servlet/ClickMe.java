package edu.javacourse.servlet;

import edu.javacourse.ru.SimpleBeanRemote;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ASaburov
 */
@WebServlet(name = "ClickMe", urlPatterns = {"/ClickMe"})
public class ClickMe extends HttpServlet {
    
    // Пример механизма injection
    //@EJB
    //private SimpleSessionBeanRemote beanRemote;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            // Представлено несколько вариантов вызова EJB через JNDI
            // Механизм injection не на всех серверах работает
            
            Context ic = new InitialContext();
            
            // вызов через шлобальный идентификатор java:global[/app-name]/module-name/bean-name
            SimpleBeanRemote beanRemote = (SimpleBeanRemote) ic.lookup("java:global/GS_EJB_First/GS_EJB_First-ejb/SimpleBean");

            // вызов через глобальный идентификатор с указанием интерфейса
            //SimpleBeanRemote beanRemote = (SimpleBeanRemote) ic.lookup("java:global/GS_EJB_First/GS_EJB_First-ejb/SimpleBean!edu.javacourse.ru.SimpleBeanRemote");

            // вызов через идентификатор GlassFish
            //SimpleBeanRemote beanRemote = (SimpleBeanRemote) ic.lookup("edu.javacourse.ru.SimpleBeanRemote");

            // Пример вызова по имени с атрибутом mappedBy - см. New SessionBean.java
            //SimpleBeanRemote beanRemote = (SimpleBeanRemote) ic.lookup("SimpleName");

            beanRemote.businessMethod();
            
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ClickMe</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ClickMe: </h1>");
            out.println("</body>");
            out.println("</html>");
        } catch (NamingException ex) {
            ex.printStackTrace();
        } finally {
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}
