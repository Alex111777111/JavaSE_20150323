/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.javacourse.ru;

import javax.ejb.Remote;

/**
 *
 * @author ASaburov
 */
@Remote
public interface SimpleBeanRemote {

    void businessMethod();
    
}
