package edu.javacourse.ejb;

import javax.ejb.Stateless;

@Stateless(name="Call1")
public class CalledBean1 implements CalledBeanLocal {

    @Override
    public void printHello() {
        System.out.println("HELLO FIRST");
    }
}
