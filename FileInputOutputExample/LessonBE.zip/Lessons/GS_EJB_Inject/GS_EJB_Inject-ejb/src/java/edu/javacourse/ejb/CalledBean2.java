package edu.javacourse.ejb;

import javax.ejb.Stateless;

@Stateless(name="Call2")
public class CalledBean2 implements CalledBeanLocal {

    @Override
    public void printHello() {
        System.out.println("HELLO SECOND");
    }
}
