/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.javacourse.ejb;

import javax.ejb.Local;

/**
 *
 * @author ASaburov
 */
@Local
public interface CalledBeanLocal {

    void printHello();
    
}
