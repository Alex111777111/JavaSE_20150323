package edu.javacourse.ejb;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.inject.Inject;

@Stateless
@LocalBean
public class TestInjectionBean {

    @EJB(beanName="Call1")
    private CalledBeanLocal beanCalled1;
    @EJB(beanName="Call2")
    private CalledBeanLocal beanCalled2;
    
    public void businessMethod() {
        beanCalled1.printHello();
        beanCalled2.printHello();
    }
}
