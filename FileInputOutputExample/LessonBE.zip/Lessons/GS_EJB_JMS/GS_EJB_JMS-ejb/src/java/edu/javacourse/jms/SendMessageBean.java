package edu.javacourse.jms;

import java.util.Calendar;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;

/**
 *
 * @author ASaburov
 */
@Stateless
@LocalBean
public class SendMessageBean {

    // Set JNDI name in the GlassFish (section JMS Resources->Connection Factories - "jms/GeminiTestQueueFactory"
    @Resource(mappedName = "jms/GeminiTestQueueFactory")
    private ConnectionFactory connectionQueueFactory;
    // Set JNDI name in the GlassFish (section JMS Resources->Destination Resources - "jms/GeminiTestQueue"
    // Class javax.jms.Queue
    @Resource(mappedName = "jms/GeminiTestQueue")
    private Queue queue;
    // Set JNDI name in the GlassFish (section JMS Resources->Connection Factories
    @Resource(mappedName = "jms/GeminiTestTopicFactory")
    private ConnectionFactory connectionTopicFactory;
    // Set JNDI name in the GlassFish (section JMS Resources->Destination Resources
    // Class javax.jms.Topic
    @Resource(mappedName = "jms/GeminiTestTopic")
    private Topic topic;

    public void sendMessageToQueue() {
        try {
            Connection connection = connectionQueueFactory.createConnection();
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            MessageProducer messageProducer = session.createProducer(queue);
            TextMessage message = session.createTextMessage();
            for (int i = 0; i < 20; i++) {
                message.setText("This is message " + (i + 1));
                message.setStringProperty("DIST", "DIST");
                System.out.println("Sending message: " + message.getText() + " "+Calendar.getInstance().getTime().toString());
                messageProducer.send(message);
            }
        } catch (JMSException ex) {
            ex.printStackTrace();
            System.out.println(ex.getMessage());
        }
    }

    public void sendMessageToTopic() {
        try {
            Connection connection = connectionTopicFactory.createConnection();
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            MessageProducer messageProducer = session.createProducer(topic);
            TextMessage message = session.createTextMessage();
            for (int i = 0; i < 10; i++) {
                message.setText("This is message " + (i + 1));
                System.out.println("Sending message: " + message.getText() + " "+Calendar.getInstance().getTime().toString());
                messageProducer.send(message);
            }
        } catch (JMSException ex) {
            ex.printStackTrace();
            System.out.println(ex.getMessage());
        }
    }
}
