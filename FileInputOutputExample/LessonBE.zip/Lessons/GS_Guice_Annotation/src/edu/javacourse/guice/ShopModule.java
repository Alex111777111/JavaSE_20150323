package edu.javacourse.guice;

import com.google.inject.AbstractModule;
import com.google.inject.name.Names;
import edu.javacourse.guice.processor.OrderProcessor;
import edu.javacourse.guice.processor.PayProcessor;
import edu.javacourse.guice.processor.RealOrderProcessor;
import edu.javacourse.guice.processor.RealPayProcessor;

public class ShopModule extends AbstractModule {

    @Override
    protected void configure() {
        // Теперь только те параметры, которые помечены @RealPay и имеют класс PayProcessor будут
        // инициализироваться RealPayProcessor
        bind(PayProcessor.class).annotatedWith(RealPay.class).to(RealPayProcessor.class);
        //bind(PayProcessor.class).to(RealPayProcessor.class);

        // Другой вариант конкретизации - через имя
        bind(OrderProcessor.class).annotatedWith(Names.named("RealOrder")).to(RealOrderProcessor.class);
        //bind(OrderProcessor.class).to(RealOrderProcessor.class);

        // Вариант инициализации простого типа
        bind(String.class).annotatedWith(Names.named("OrderProcessorID")).toInstance("ProcessorID=1000");
    }
}
