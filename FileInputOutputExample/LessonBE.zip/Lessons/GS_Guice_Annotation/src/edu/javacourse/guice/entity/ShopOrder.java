package edu.javacourse.guice.entity;

public class ShopOrder {
    
}
