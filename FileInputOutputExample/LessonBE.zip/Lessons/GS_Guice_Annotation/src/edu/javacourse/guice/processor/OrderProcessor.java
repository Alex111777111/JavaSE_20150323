package edu.javacourse.guice.processor;

import edu.javacourse.guice.entity.ShopOrder;

public interface OrderProcessor {
    public void processOrder(ShopOrder shopOrder);
}
