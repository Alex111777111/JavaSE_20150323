package edu.javacourse.guice.processor;

import edu.javacourse.guice.entity.CardNumber;

public interface PayProcessor {
    public void processCard(CardNumber cardNumber);
}
