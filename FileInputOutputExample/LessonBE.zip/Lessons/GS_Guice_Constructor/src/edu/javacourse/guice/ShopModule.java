package edu.javacourse.guice;

import com.google.inject.AbstractModule;
import com.google.inject.name.Names;
import edu.javacourse.guice.processor.OrderProcessor;
import edu.javacourse.guice.processor.PayProcessor;
import edu.javacourse.guice.processor.RealOrderProcessor;
import edu.javacourse.guice.processor.RealPayProcessor;

public class ShopModule extends AbstractModule {

    @Override
    protected void configure() {
        try {
            // Можно вызывать разные конструкторы
            //bind(OrderProcessor.class).toConstructor(RealOrderProcessor.class.getConstructor());
            bind(OrderProcessor.class).toConstructor(RealOrderProcessor.class.getConstructor(String.class));
        } catch (NoSuchMethodException e) {
            addError(e);
        }
        bind(PayProcessor.class).to(RealPayProcessor.class);
        bind(String.class).annotatedWith(Names.named("OrderProcessorID")).toInstance("ProcessorID=1000");
    }
}
