package edu.javacourse.guice;

import com.google.inject.Inject;
import edu.javacourse.guice.processor.OrderProcessor;
import edu.javacourse.guice.processor.PayProcessor;
import edu.javacourse.guice.entity.CardNumber;
import edu.javacourse.guice.entity.ShopOrder;

public class ShopService {

    private OrderProcessor orderProcessor;
    private PayProcessor payProcessor;

    @Inject
    public ShopService(OrderProcessor orderProcessor, PayProcessor payProcessor) {
        this.orderProcessor = orderProcessor;
        this.payProcessor = payProcessor;
    }
    
    public void makeOrderProcess(ShopOrder shopOrder, CardNumber carNumber) {
        orderProcessor.processOrder(shopOrder);
        payProcessor.processCard(carNumber);
    }
}
