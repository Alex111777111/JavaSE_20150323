package edu.javacourse.guice.processor;

import com.google.inject.name.Named;
import edu.javacourse.guice.entity.ShopOrder;

public class RealOrderProcessor implements OrderProcessor {

    private String processorId;
    
    public RealOrderProcessor() {
        System.out.println("Default constructor");
    }

    public RealOrderProcessor(@Named("OrderProcessorID") String processorId) {
        System.out.println("Constructor with parameter:" + processorId);
        this.processorId = processorId;
    }

    @Override
    public void processOrder(ShopOrder shopOrder) {
        System.out.println("Real Order Processor:" + processorId);
    }
}
