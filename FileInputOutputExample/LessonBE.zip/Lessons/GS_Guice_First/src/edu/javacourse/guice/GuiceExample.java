package edu.javacourse.guice;

import edu.javacourse.guice.entity.CardNumber;
import edu.javacourse.guice.entity.ShopOrder;
import edu.javacourse.guice.processor.OrderProcessorFactory;
import edu.javacourse.guice.processor.PayProcessorFactory;
import edu.javacourse.guice.processor.RealOrderProcessor;
import edu.javacourse.guice.processor.RealPayProcessor;

public class GuiceExample {

    public static void main(String[] args) {
        // Самый неудачный вариант создания
        ShopService ss1 = new ShopService(new RealOrderProcessor(), new RealPayProcessor());
        ss1.makeOrderProcess(new ShopOrder(), new CardNumber());
        
        // Создание через фабрику
        ShopService ss2 = new ShopService(OrderProcessorFactory.getInstance(), PayProcessorFactory.getInstance());
        ss2.makeOrderProcess(new ShopOrder(), new CardNumber());
    }
}
