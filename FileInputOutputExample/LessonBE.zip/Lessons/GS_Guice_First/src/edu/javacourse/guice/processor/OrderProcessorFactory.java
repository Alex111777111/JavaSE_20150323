package edu.javacourse.guice.processor;

public class OrderProcessorFactory {

    private static OrderProcessor instance;

    public static void setInstance(OrderProcessor orderProcessor) {
        instance = orderProcessor;
    }

    public static OrderProcessor getInstance() {
        if (instance == null) {
            return new RealOrderProcessor();
        }

        return instance;
    }
}
