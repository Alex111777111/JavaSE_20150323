package edu.javacourse.guice.processor;

public class PayProcessorFactory {

    private static PayProcessor instance;

    public static void setInstance(PayProcessor payProcessor) {
        instance = payProcessor;
    }

    public static PayProcessor getInstance() {
        if (instance == null) {
            return new RealPayProcessor();
        }

        return instance;
    }
}
