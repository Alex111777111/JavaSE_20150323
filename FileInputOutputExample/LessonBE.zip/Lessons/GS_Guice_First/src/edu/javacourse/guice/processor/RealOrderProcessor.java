package edu.javacourse.guice.processor;

import edu.javacourse.guice.entity.ShopOrder;

public class RealOrderProcessor implements OrderProcessor {

    @Override
    public void processOrder(ShopOrder shopOrder) {
        System.out.println("Real Order Processor");
    }
    
}
