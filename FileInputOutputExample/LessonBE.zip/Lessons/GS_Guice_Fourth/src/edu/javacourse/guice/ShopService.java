package edu.javacourse.guice;

import com.google.inject.Inject;
import edu.javacourse.guice.processor.OrderProcessor;
import edu.javacourse.guice.processor.PayProcessor;
import edu.javacourse.guice.entity.CardNumber;
import edu.javacourse.guice.entity.ShopOrder;


public class ShopService {

    @Inject
    private OrderProcessor orderProcessor;
    @Inject
    private PayProcessor payProcessor;

    public ShopService() {
    }
    
    public void makeOrderProcess(ShopOrder shopOrder, CardNumber carNumber) {
        orderProcessor.processOrder(shopOrder);
        payProcessor.processCard(carNumber);
    }
}
