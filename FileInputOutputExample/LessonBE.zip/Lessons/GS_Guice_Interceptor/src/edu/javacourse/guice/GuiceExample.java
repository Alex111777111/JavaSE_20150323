package edu.javacourse.guice;

import com.google.inject.AbstractModule;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Stage;
import com.google.inject.matcher.Matchers;
import edu.javacourse.guice.entity.CardNumber;
import edu.javacourse.guice.entity.ShopOrder;
import edu.javacourse.guice.interceptor.ClassAnnotation;
import edu.javacourse.guice.interceptor.MethodAnnotation;
import edu.javacourse.guice.interceptor.TestInterceptor;

public class GuiceExample {

    public static void main(String[] args) {
        Injector injector = Guice.createInjector(Stage.DEVELOPMENT, new AbstractModule() {
            @Override
            protected void configure() {
                // Интерсептор будет работать на все классы и все методы
                bindInterceptor(Matchers.any(), Matchers.any(), new TestInterceptor());

                // Интерсептор будет работать на классы с аннотацией и на все методы
//                bindInterceptor(Matchers.annotatedWith(ClassAnnotation.class), 
//                        Matchers.any(), 
//                        new TestInterceptor());
                
                // Интерсептор будет работать на классы с аннотацией и на методы с аннотацией
//                bindInterceptor(Matchers.annotatedWith(ClassAnnotation.class), 
//                        Matchers.annotatedWith(MethodAnnotation.class), 
//                        new TestInterceptor());
            }
        });
        ShopService ss = injector.getInstance(ShopService.class);
        ss.makeOrderProcess(new ShopOrder(), new CardNumber());
    }
}
