package edu.javacourse.guice;

import com.google.inject.Inject;
import edu.javacourse.guice.entity.CardNumber;
import edu.javacourse.guice.entity.ShopOrder;
import edu.javacourse.guice.processor.RealOrderProcessor;
import edu.javacourse.guice.processor.RealPayProcessor;

public class ShopService {

    @Inject
    private RealOrderProcessor orderProcessor;
    @Inject
    private RealPayProcessor payProcessor;

    public void makeOrderProcess(ShopOrder shopOrder, CardNumber carNumber) {
        orderProcessor.processOrder(shopOrder);
        payProcessor.processCard(carNumber);
    }
}
