package edu.javacourse.guice.interceptor;

import java.lang.annotation.Retention;

@Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
public @interface ClassAnnotation {
}
