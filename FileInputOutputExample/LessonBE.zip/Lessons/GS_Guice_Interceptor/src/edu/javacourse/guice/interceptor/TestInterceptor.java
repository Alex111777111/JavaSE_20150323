package edu.javacourse.guice.interceptor;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class TestInterceptor implements MethodInterceptor {

    @Override
    public Object invoke(MethodInvocation mi) throws Throwable {
        System.out.println("Before " + mi.getMethod().getDeclaringClass().getSimpleName() + "." + mi.getMethod().getName());
        Object obj = mi.proceed();
        System.out.println("After " + mi.getMethod().getDeclaringClass().getSimpleName() + "." + mi.getMethod().getName());
        return obj;
    }
    
}
