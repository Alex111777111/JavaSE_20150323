package edu.javacourse.guice.processor;

import com.google.inject.name.Named;
import edu.javacourse.guice.entity.ShopOrder;
import edu.javacourse.guice.interceptor.ClassAnnotation;
import edu.javacourse.guice.interceptor.MethodAnnotation;

@ClassAnnotation
public class RealOrderProcessor {

    public void processOrder(ShopOrder shopOrder) {
        System.out.println("Real Order Processor");
    }
}
