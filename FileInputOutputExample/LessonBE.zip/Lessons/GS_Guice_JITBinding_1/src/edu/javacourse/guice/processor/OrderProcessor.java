package edu.javacourse.guice.processor;

import com.google.inject.ImplementedBy;
import edu.javacourse.guice.entity.ShopOrder;

@ImplementedBy(RealOrderProcessor.class)
public interface OrderProcessor {

    public void processOrder(ShopOrder shopOrder);
}
