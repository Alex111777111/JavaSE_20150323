package edu.javacourse.guice.processor;

import com.google.inject.ImplementedBy;
import edu.javacourse.guice.entity.CardNumber;

@ImplementedBy(RealPayProcessor.class)
public interface PayProcessor {
    public void processCard(CardNumber cardNumber);
}
