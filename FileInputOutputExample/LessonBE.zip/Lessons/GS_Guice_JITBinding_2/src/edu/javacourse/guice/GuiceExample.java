package edu.javacourse.guice;

import com.google.inject.AbstractModule;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.name.Names;
import edu.javacourse.guice.entity.CardNumber;
import edu.javacourse.guice.entity.ShopOrder;

public class GuiceExample {

    public static void main(String[] args) {
        Injector injector = Guice.createInjector(new AbstractModule() {
            @Override
            protected void configure() {
                bind(String.class).annotatedWith(Names.named("ProcessorId")).toInstance("1234567890");
            }
        });

        ShopService ss1 = injector.getInstance(ShopService.class);
        ss1.makeOrderProcess(new ShopOrder(), new CardNumber());
    }
}
