package edu.javacourse.guice.processor;

import com.google.inject.ProvidedBy;
import edu.javacourse.guice.entity.ShopOrder;

@ProvidedBy(OrderProcessorProvider.class)
public interface OrderProcessor {
    public void processOrder(ShopOrder shopOrder);
}
