package edu.javacourse.guice;

import com.google.inject.Guice;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.google.inject.persist.PersistService;
import com.google.inject.persist.Transactional;
import com.google.inject.persist.jpa.JpaPersistModule;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import javax.persistence.EntityManager;

public class GuicePersist {

    @Inject
    private EntityManager em;

    @Transactional(rollbackOn = {IOException.class, RuntimeException.class})
    //@Transactional(rollbackOn = { IOException.class, RuntimeException.class}, ignore = FileNotFoundException.class)
    private void testRegion() {
        List<Region> result = em.createQuery("SELECT r FROM Region r").getResultList();
        for (Region r : result) {
            System.out.println(r.getRegionId() + ":" + r.getRegionName());
        }
    }

    public static void main(String[] args) {
        Injector injector = Guice.createInjector(new JpaPersistModule("GS_Guice_PersistPU"));

        // Стартовать систему поддержки PERSIST JPA
        PersistService ps = injector.getInstance(PersistService.class);
        ps.start();

        GuicePersist gp = injector.getInstance(GuicePersist.class);
        gp.testRegion();

        // Остановить систему поддержки PERSIST JPA
        ps.stop();
    }
}
