package edu.javacourse.guice;

import com.google.inject.Guice;
import com.google.inject.Injector;
import edu.javacourse.guice.entity.CardNumber;
import edu.javacourse.guice.entity.ShopOrder;

public class GuiceExample {

    public static void main(String[] args) {
        Injector injector = Guice.createInjector(new ShopModule());

        ShopService ss1 = injector.getInstance(ShopService.class);
        ss1.makeOrderProcess(new ShopOrder(), new CardNumber());
    }
}
