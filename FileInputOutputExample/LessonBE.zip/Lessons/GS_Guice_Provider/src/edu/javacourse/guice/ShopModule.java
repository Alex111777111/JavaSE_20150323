package edu.javacourse.guice;

import com.google.inject.AbstractModule;
import com.google.inject.name.Names;
import edu.javacourse.guice.processor.OrderProcessor;
import edu.javacourse.guice.processor.OrderProcessorProvider;
import edu.javacourse.guice.processor.PayProcessor;
import edu.javacourse.guice.processor.RealPayProcessor;

public class ShopModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(OrderProcessor.class).toProvider(OrderProcessorProvider.class);
        
        bind(PayProcessor.class).to(RealPayProcessor.class);

        bind(String.class).annotatedWith(Names.named("OrderProcessorID")).toInstance("ProcessorID=1000");
    }
}
