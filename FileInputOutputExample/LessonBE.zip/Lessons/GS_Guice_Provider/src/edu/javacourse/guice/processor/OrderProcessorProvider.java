package edu.javacourse.guice.processor;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.google.inject.name.Named;

public class OrderProcessorProvider implements Provider<OrderProcessor> {

    private String processorId;

    @Inject
    public OrderProcessorProvider(@Named("OrderProcessorID") String processorId) {
        this.processorId = processorId;
    }
    
    @Override
    public OrderProcessor get() {
        System.out.println("Create through Provider Class");
        RealOrderProcessor orderProcessor = new RealOrderProcessor();
        orderProcessor.setProcessorId(processorId);
        return orderProcessor;
    }
}
