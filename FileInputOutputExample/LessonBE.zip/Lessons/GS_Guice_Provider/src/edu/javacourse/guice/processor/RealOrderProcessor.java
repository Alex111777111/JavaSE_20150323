package edu.javacourse.guice.processor;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import edu.javacourse.guice.entity.ShopOrder;

public class RealOrderProcessor implements OrderProcessor {

    @Inject
    @Named("OrderProcessorID")
    private String processorId;

    public String getProcessorId() {
        return processorId;
    }

    public void setProcessorId(String processorId) {
        this.processorId = processorId;
    }

    @Override
    public void processOrder(ShopOrder shopOrder) {
        System.out.println("Real Order Processor:" + processorId);
    }
}
