package edu.javacourse.guice;

import com.google.inject.AbstractModule;
import com.google.inject.Provides;
import com.google.inject.Singleton;
import com.google.inject.name.Named;
import com.google.inject.name.Names;
import edu.javacourse.guice.processor.OrderProcessor;
import edu.javacourse.guice.processor.PayProcessor;
import edu.javacourse.guice.processor.RealOrderProcessor;
import edu.javacourse.guice.processor.RealPayProcessor;

public class ShopModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(PayProcessor.class).to(RealPayProcessor.class);

        bind(String.class).annotatedWith(Names.named("OrderProcessorID")).toInstance("ProcessorID=1000");
    }

    @Provides
    @Named("RealOrder")
    @Singleton
    OrderProcessor provideOrderProcessor(@Named("OrderProcessorID") String processorId) {
        System.out.println("Create through @Provides - first version");
        RealOrderProcessor orderProcessor = new RealOrderProcessor();
        orderProcessor.setProcessorId(processorId);
        return orderProcessor;
    }
}
