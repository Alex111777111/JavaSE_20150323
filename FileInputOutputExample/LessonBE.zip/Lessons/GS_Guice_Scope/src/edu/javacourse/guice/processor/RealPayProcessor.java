package edu.javacourse.guice.processor;

import com.google.inject.Singleton;
import edu.javacourse.guice.entity.CardNumber;

@Singleton
public class RealPayProcessor implements PayProcessor {

    @Override
    public void processCard(CardNumber cardNumber) {
        System.out.println("Real Pay Processor");
    }
    
}
