package edu.javacourse.guice;

import com.google.inject.AbstractModule;
import edu.javacourse.guice.processor.OrderProcessor;
import edu.javacourse.guice.processor.PayProcessor;
import edu.javacourse.guice.processor.RealOrderProcessor;
import edu.javacourse.guice.processor.RealPayProcessor;

public class ShopModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(OrderProcessor.class).to(RealOrderProcessor.class);
        // Эту строку можно не использовать, если мы связываемся не через интерфейс
        bind(PayProcessor.class).to(RealPayProcessor.class);
    }
}
