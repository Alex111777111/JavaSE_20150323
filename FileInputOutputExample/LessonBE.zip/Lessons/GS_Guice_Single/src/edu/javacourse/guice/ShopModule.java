package edu.javacourse.guice;

import com.google.inject.AbstractModule;
import com.google.inject.Singleton;
import edu.javacourse.guice.processor.OrderProcessor;
import edu.javacourse.guice.processor.PayProcessor;
import edu.javacourse.guice.processor.RealOrderProcessor;
import edu.javacourse.guice.processor.RealPayProcessor;

public class ShopModule extends AbstractModule {

    @Override
    protected void configure() {
        // Связывание без указание цели
        //bind(ShopService.class);
        // Связывание с указанием что объект один
        //bind(ShopService.class).in(Singleton.class);
        bind(ShopService.class).asEagerSingleton();
        
        bind(OrderProcessor.class).to(RealOrderProcessor.class);
        bind(PayProcessor.class).to(RealPayProcessor.class);
    }
}
