package edu.javacourse.guice;

import com.google.inject.Inject;
import edu.javacourse.guice.entity.CardNumber;
import edu.javacourse.guice.entity.ShopOrder;
import edu.javacourse.guice.processor.RealOrderProcessor;
import edu.javacourse.guice.processor.RealPayProcessor;

public class ShopService {

    @Inject
    private RealOrderProcessor orderProcessor;
    @Inject
    private RealPayProcessor payProcessor;

    // Можно использовать конструктор по умолчанию
    public ShopService() {
        System.out.println("ShopService");
    }
    
    // Другой вариант вызова - можно убрать @Inject у полей
//    @Inject    
//    public ShopService(RealOrderProcessor orderProcessor, RealPayProcessor payProcessor) {
//        System.out.println("ShopService and params");
//        this.orderProcessor = orderProcessor;
//        this.payProcessor = payProcessor;
//    }
    
    public void makeOrderProcess(ShopOrder shopOrder, CardNumber carNumber) {
        orderProcessor.processOrder(shopOrder);
        payProcessor.processCard(carNumber);
    }
}
