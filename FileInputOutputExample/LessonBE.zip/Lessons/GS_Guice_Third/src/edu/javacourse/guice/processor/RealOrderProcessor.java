package edu.javacourse.guice.processor;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import edu.javacourse.guice.entity.ShopOrder;

public class RealOrderProcessor {

    @Inject
    // Если мы не хотим делать обязательное связывание в значение в модуле, то можно добавить optional
    //@Inject(optional=true)
    @Named("MyString")
    private String processorId;
    
    public RealOrderProcessor() {
        System.out.println("RealOrderProcessor");
    }
    
    public void processOrder(ShopOrder shopOrder) {
        System.out.println("Real Order Processor:" + processorId);
    }
}
