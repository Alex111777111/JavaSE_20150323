package edu.javacourse.guice.processor;

import edu.javacourse.guice.entity.CardNumber;

public class RealPayProcessor {

    public RealPayProcessor() {
        System.out.println("RealPayProcessor");
    }

    public void processCard(CardNumber cardNumber) {
        System.out.println("Real Pay Processor");
    }
}
