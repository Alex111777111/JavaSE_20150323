package edu.javacourse.hessian;

public interface Basic {

    public String sayHello();
}