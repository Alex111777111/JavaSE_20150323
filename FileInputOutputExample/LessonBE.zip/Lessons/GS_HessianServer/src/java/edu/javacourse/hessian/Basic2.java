package edu.javacourse.hessian;

public interface Basic2 {

    public String sayHello2();
}