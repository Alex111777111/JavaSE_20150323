package edu.javacourse.hessian;

public class BasicService implements Basic {

    private String _greeting = "Hello, world";

    public void setGreeting(String greeting) {
        _greeting = greeting;
    }

    public String sayHello() {
        return _greeting;
    }
}