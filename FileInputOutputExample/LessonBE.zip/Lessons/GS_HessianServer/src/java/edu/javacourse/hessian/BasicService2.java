package edu.javacourse.hessian;

public class BasicService2 implements Basic2 {

    private String _greeting = "Hello, world 2";

    public void setGreeting(String greeting) {
        _greeting = greeting;
    }

    public String sayHello2() {
        return _greeting;
    }
}