package edu.javacourse.hessian.client;

import com.caucho.hessian.client.HessianProxyFactory;
import edu.javacourse.hessian.Basic;
import edu.javacourse.hessian.Basic2;

public class BasicServiceClient {

    public static void main(String[] args) throws Exception {
        {
            String url = "http://localhost:8084/GS_HessianServer/hello";

            HessianProxyFactory factory = new HessianProxyFactory();
            Basic basic = (Basic) factory.create(Basic.class, url);

            System.out.println("Hello: " + basic.sayHello());
        }
        {
            String url = "http://localhost:8084/GS_HessianServer/hello2";

            HessianProxyFactory factory = new HessianProxyFactory();
            Basic2 basic = (Basic2) factory.create(Basic2.class, url);

            System.out.println("Hello: " + basic.sayHello2());
        }
    }
}